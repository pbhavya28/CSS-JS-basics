module.exports.errorHandler = function(err) {
    if(err) {
        console.log("Error occurred: ", err);
    }
}